// === My_ST7796_Setup.h ===

#define ST7796_DRIVER

// Control pins
#define TFT_CS     4  // Chip select control pin
#define TFT_DC     3  // Data Command control pin
#define TFT_RST    5  // Reset pin

// SPI bus (UNO R4 uses fixed SPI pins)
#define TFT_MOSI  11
#define TFT_SCLK  13
#define TFT_MISO  12  // Optional

// Display size (if not auto-detected)
#define TFT_WIDTH  320
#define TFT_HEIGHT 480

// SPI frequency
#define SPI_FREQUENCY       40000000
#define SPI_READ_FREQUENCY  20000000
#define SPI_TOUCH_FREQUENCY 2500000

// Fonts to load (optional, saves flash if you only need some)
#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT4
#define LOAD_FONT6
#define LOAD_FONT7
#define LOAD_FONT8
#define LOAD_GFXFF